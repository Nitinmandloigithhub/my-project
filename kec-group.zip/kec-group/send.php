<?php

         $fname = $_POST['fname1'];
		 $fphone = $_POST['fphone1'];
		 $femail = $_POST['femail1'];
		 $fmessage = $_POST['fmessage1'];
		
		
// $to = "anurag.pandey17@gmail.com";		
 $to = "abhi.alphaklick@gmail.com";
 $subject = "Contact Query";
 $message = "<html>
<head>
<title>Contact Us</title>
</head>

<body>

<table border='0' cellpadding='0' cellspacing='0' height='100%' id='ox-d2f7efa94a-backgroundTable' style='border-collapse: collapse; margin: 0;padding: 0;background-color: #FAFAFA;height: 100%;width: 100%;' width='100%'>
	<tbody>
		<tr>
			<td align='center' style='padding: 0px; border-collapse: collapse;' valign='top'><table border='0' cellpadding='0' cellspacing='0' id='ox-d2f7efa94a-templateContainer' style='border-collapse: collapse; border: 1px solid #DDDDDD;background-color: #FFFFFF;' width='600'>
				<tbody>
					
					<tr>
						<td align='center' style='padding: 0px; border-collapse: collapse;' valign='top'>
						<table border='1' cellpadding='10' cellspacing='0' width='100%' style='border-collapse: collapse;'>
  <tbody>
		<tr>
			<td colspan='2' style='padding: 10px; background: #e3e3e3;' valign='top'>
			<center><strong>Get In Touch With Us</strong></center>
			</td>
		</tr>
				
		<tr>
			<td style='padding: 10px; width: 33%; text-align: right;' valign='top'><strong>Name:</strong></td>
			<td style='padding: 10px;'>".$fname." </td>
		</tr>
		
		<tr>
			<td style='padding: 10px; width: 33%; text-align: right;' valign='top'><strong>Phone:</strong></td>
			<td style='padding: 10px;'>".$fphone."</td>
		</tr>
		<tr>
			<td style='padding: 10px; width: 33%; text-align: right;' valign='top'><strong>Email:</strong></td>
			<td style='padding: 10px;'><a href='mailto:".$femail."' class='mailto-link' target='_blank'>".$femail."</a></td>
		</tr>
		<tr>
			<td style='padding: 10px; width: 33%; text-align: right;' valign='top'><strong>Message:</strong></td>
			<td style='padding: 10px;'>".$fmessage."</td>
		</tr>
	</tbody>
</table>
						</td>
					</tr>
					
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>

</body>
</html>";

// Always set content-type when sending HTML email
    $headers  = 'From: info@controlf5.in' . "\r\n" ;
    $headers .='Reply-To: '. $to . "\r\n" ;
    $headers .='X-Mailer: PHP/' . phpversion();
    $headers .= "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
//$headers .= 'From: <'.$femail.'>' . "\r\n";

		if(mail($to, $subject, $message, $headers)) { 
		echo "success";				
		}	
		else
		{
		echo "invalid";
			}
			
				
?>
